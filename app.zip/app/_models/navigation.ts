export interface navigation{
    id: number,
    title: string,
    route: string
}