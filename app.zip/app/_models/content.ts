export interface content{
    id: number,
    title: string,
    description: string
}