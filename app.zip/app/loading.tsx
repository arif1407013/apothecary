import React from 'react'

const Loading = () => {
  return (
    <div>Loading Data ....</div>
  )
}

export default Loading