import React from 'react'

const page = () => {
  return (
    <div>Login</div>
  )
}

export default page