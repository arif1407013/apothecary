import React from 'react'

const page = () => {
  return (
    <div>Forgot Password</div>
  )
}

export default page