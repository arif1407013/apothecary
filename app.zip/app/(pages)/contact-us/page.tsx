import React from 'react'

const page = () => {
  return (
    <div>Contact Us</div>
  )
}

export default page