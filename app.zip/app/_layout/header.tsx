import React from 'react'

const Header = () => {
  return (
    <div className='py-6 bg-red-100'>Header</div>
  )
}

export default Header;