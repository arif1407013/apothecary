import React from 'react'

const Footer = () => {
  return (
    <div className='py-6 bg-amber-100'>Footer</div>
  )
}

export default Footer;